Generated public B1.3 curved S8 shell only. No company/user CAD is included.
The exact saved project was reopened once for read-only stamp diagnosis.
Only mesh_source.brep and reference_geometry/CurvedPatch/brep differ.
The native mesh hash, source IDs, placements, fixed references and all other
binding fields are equal. Saved draft/applied/source project were unchanged.
The pre-save exportBrepToString text was not separately retained. A geometry
equivalence verdict or a merely cosmetic serialization change is NOT claimed.
Current exportBrepToString and the exact saved FCStd's native Shape.brp are kept
separately: neither is relabeled as the missing pre-save export text.
No new geometry, remesh, Apply, solver, binding repair, or engineering release.
diagnostic/native-check.json confirms the invocation-owned Job is empty.
source/mesh.json is the prepared model from the original non-solver native run.
source/design.caepre contains the actual saved FCStd and its checked manifest.
